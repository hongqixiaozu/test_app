## MaxLeapMall

打开 `Android Studio` 或 `IDEA`, 点击 `File` -> `Open` -> 选择工程目录下的 `settings.gradle` 文件.